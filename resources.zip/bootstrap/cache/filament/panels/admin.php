<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.article-resource.pages.create-article' => 'App\\Filament\\Resources\\ArticleResource\\Pages\\CreateArticle',
    'app.filament.resources.article-resource.pages.edit-article' => 'App\\Filament\\Resources\\ArticleResource\\Pages\\EditArticle',
    'app.filament.resources.article-resource.pages.list-articles' => 'App\\Filament\\Resources\\ArticleResource\\Pages\\ListArticles',
    'app.filament.resources.contact-resource.pages.create-contact' => 'App\\Filament\\Resources\\ContactResource\\Pages\\CreateContact',
    'app.filament.resources.contact-resource.pages.edit-contact' => 'App\\Filament\\Resources\\ContactResource\\Pages\\EditContact',
    'app.filament.resources.contact-resource.pages.list-contacts' => 'App\\Filament\\Resources\\ContactResource\\Pages\\ListContacts',
    'app.filament.resources.subscribe-resource.pages.create-subscribe' => 'App\\Filament\\Resources\\SubscribeResource\\Pages\\CreateSubscribe',
    'app.filament.resources.subscribe-resource.pages.edit-subscribe' => 'App\\Filament\\Resources\\SubscribeResource\\Pages\\EditSubscribe',
    'app.filament.resources.subscribe-resource.pages.list-subscribes' => 'App\\Filament\\Resources\\SubscribeResource\\Pages\\ListSubscribes',
    'app.filament.resources.tag-resource.pages.create-tag' => 'App\\Filament\\Resources\\TagResource\\Pages\\CreateTag',
    'app.filament.resources.tag-resource.pages.edit-tag' => 'App\\Filament\\Resources\\TagResource\\Pages\\EditTag',
    'app.filament.resources.tag-resource.pages.list-tags' => 'App\\Filament\\Resources\\TagResource\\Pages\\ListTags',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.widgets.filament-info-widget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'C:\\Users\\Admin\\Documents\\Project\\Full\\blog\\blog\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'C:\\Users\\Admin\\Documents\\Project\\Full\\blog\\blog\\app\\Filament\\Resources\\ArticleResource.php' => 'App\\Filament\\Resources\\ArticleResource',
    'C:\\Users\\Admin\\Documents\\Project\\Full\\blog\\blog\\app\\Filament\\Resources\\ContactResource.php' => 'App\\Filament\\Resources\\ContactResource',
    'C:\\Users\\Admin\\Documents\\Project\\Full\\blog\\blog\\app\\Filament\\Resources\\SubscribeResource.php' => 'App\\Filament\\Resources\\SubscribeResource',
    'C:\\Users\\Admin\\Documents\\Project\\Full\\blog\\blog\\app\\Filament\\Resources\\TagResource.php' => 'App\\Filament\\Resources\\TagResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\Users\\Admin\\Documents\\Project\\Full\\blog\\blog\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'C:\\Users\\Admin\\Documents\\Project\\Full\\blog\\blog\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);