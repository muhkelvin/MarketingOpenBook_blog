<?php $__env->startSection('title', 'Articles tagged: ' . $tag->name); ?>
<?php $__env->startSection('meta_description', 'Browse articles tagged with ' . $tag->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-7xl mx-auto px-4 lg:px-8 py-12">
        <header class="mb-16 text-center">
            <h1 class="font-playfair text-4xl lg:text-5xl text-secondary mb-4">
                Tag: <span class="text-accent"><?php echo e($tag->name); ?></span>
            </h1>
            <p class="font-montserrat text-darkgray/80 text-lg">
                Exploring articles related to <span class="font-semibold text-accent"><?php echo e($tag->name); ?></span>
            </p>
        </header>

        <?php if($articles->count()): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="relative bg-white rounded-xl shadow-sm hover:shadow-xl transition-all duration-300 group overflow-hidden">
                        <!-- Gradient Overlay -->
                        <div class="absolute inset-0 bg-gradient-to-br from-accent/10 to-sage/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>

                        <?php if($article->image): ?>
                            <div class="relative h-60 overflow-hidden rounded-t-xl">
                                <img src="<?php echo e($article->image); ?>" alt="<?php echo e($article->title); ?>"
                                     class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105">
                                <div class="absolute inset-0 bg-gradient-to-t from-secondary/40 to-transparent"></div>
                            </div>
                        <?php endif; ?>

                        <div class="p-6">
                            <header class="mb-4">
                                <div class="flex items-center justify-between mb-3">
                                    <?php if($article->published_at): ?>
                                        <time class="text-sm text-darkgray/80 font-montserrat">
                                            <?php echo e($article->published_at->isoFormat('MMM Do, YYYY')); ?>

                                        </time>
                                    <?php endif; ?>
                                    <div class="flex space-x-2">
                                        <?php $__currentLoopData = $article->tags->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(route('tag.show', $tag->slug)); ?>"
                                               class="px-3 py-1 text-xs font-montserrat bg-sage/10 text-secondary rounded-full hover:bg-sage/20 transition-colors">
                                                #<?php echo e($tag->name); ?>

                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>

                                <h2 class="font-playfair text-2xl text-secondary leading-tight mb-2 hover:text-accent transition-colors">
                                    <a href="<?php echo e(route('articles.show', $article->slug)); ?>">
                                        <?php echo e($article->title); ?>

                                    </a>
                                </h2>
                            </header>

                            <p class="text-darkgray/90 leading-relaxed mb-4 font-lora line-clamp-3">
                                <?php echo e($article->excerpt); ?>

                            </p>

                            <div class="flex items-center justify-between">
                                <a href="<?php echo e(route('articles.show', $article->slug)); ?>"
                                   class="relative z-10 inline-flex items-center text-accent hover:text-sage transition-colors font-medium">
                                    Continue Reading
                                    <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                                    </svg>
                                </a>
                                <span class="text-sm text-darkgray/60 font-montserrat">
                                <?php echo e($article->reading_time); ?> min read
                            </span>
                            </div>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Pagination -->
            <div class="mt-16">
                <?php echo e($articles->links()); ?>

            </div>
        <?php else: ?>
            <div class="text-center py-16">
                <p class="font-montserrat text-darkgray/80 text-lg">
                    No articles found with this tag.
                </p>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Project\Full\blog\blog\resources\views\tags\show.blade.php ENDPATH**/ ?>