<?php if (isset($component)) { $__componentOriginalbe23554f7bded3778895289146189db7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbe23554f7bded3778895289146189db7 = $attributes; } ?>
<?php $component = Filament\View\LegacyComponents\Page::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Filament\View\LegacyComponents\Page::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="space-y-6 p-6">
        <header>
            <h1 class="text-3xl font-bold">Analytics Overview</h1>
            <p class="text-gray-600">Lihat ringkasan data analitik untuk konten Anda.</p>
        </header>

        <!-- Contoh card analitik -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <!-- Total Articles -->
            <div class="p-4 bg-white border border-gray-200 rounded shadow">
                <h2 class="text-xl font-semibold text-gray-800">Total Articles</h2>
                <p class="mt-2 text-3xl font-bold text-gray-900">
                    <?php echo e($totalArticles ?? '0'); ?>

                </p>
            </div>
            <!-- Daily Articles -->
            <div class="p-4 bg-white border border-gray-200 rounded shadow">
                <h2 class="text-xl font-semibold text-gray-800">Daily Articles</h2>
                <p class="mt-2 text-3xl font-bold text-gray-900">
                    <?php echo e($dailyArticles ?? '0'); ?>

                </p>
            </div>
            <!-- Weekly Articles -->
            <div class="p-4 bg-white border border-gray-200 rounded shadow">
                <h2 class="text-xl font-semibold text-gray-800">Weekly Articles</h2>
                <p class="mt-2 text-3xl font-bold text-gray-900">
                    <?php echo e($weeklyArticles ?? '0'); ?>

                </p>
            </div>
        </div>

        <!-- Section filter (opsional) -->
        <div class="mt-8">
            <label for="filter" class="block font-medium text-sm text-gray-700">
                Filter Analytics:
            </label>
            <select wire:model="filter" id="filter" class="mt-1 block w-1/3 border-gray-300 rounded-md shadow-sm">
                <option value="all">All</option>
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
            </select>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbe23554f7bded3778895289146189db7)): ?>
<?php $attributes = $__attributesOriginalbe23554f7bded3778895289146189db7; ?>
<?php unset($__attributesOriginalbe23554f7bded3778895289146189db7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe23554f7bded3778895289146189db7)): ?>
<?php $component = $__componentOriginalbe23554f7bded3778895289146189db7; ?>
<?php unset($__componentOriginalbe23554f7bded3778895289146189db7); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Admin\Documents\Project\Full\blog\blog\resources\views\filament\resources\analytics-resource\pages\analytics.blade.php ENDPATH**/ ?>