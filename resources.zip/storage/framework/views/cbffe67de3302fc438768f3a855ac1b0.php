<?php
    $defaultFormatMethod = 'scale';
    $retrieveFormattedVideo = cloudinary()->getVideoTag($publicId ?? '')
                                    ->setAttributes(['controls', 'loop', 'preload'])
                                    ->fallback('Your browser does not support HTML5 video tagsssss.')
                                    ->$defaultFormatMethod($width ?? '', $height ?? '');
?>
<?php /**PATH C:\Users\Admin\Documents\Project\Full\blog\blog\vendor\cloudinary-labs\cloudinary-laravel\resources\views\components\video.blade.php ENDPATH**/ ?>