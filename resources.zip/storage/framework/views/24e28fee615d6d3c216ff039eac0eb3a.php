<?php $__env->startSection('title', 'Categories - MarketJourney'); ?>
<?php $__env->startSection('meta_description', 'Explore articles by category'); ?>

<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white rounded-xl shadow-sm p-6">
                <h2 class="font-playfair text-2xl text-secondary mb-2">
                    <?php echo e($category->name); ?>

                </h2>
                <p class="text-darkgray/90 mb-4">
                    <?php echo e($category->articles_count); ?> articles
                </p>
                <a href="<?php echo e(route('tag.show',$category->slug)); ?>" class="text-accent hover:text-sage transition-colors">
                    View Articles →
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Project\Full\blog\blog\resources\views\categories\index.blade.php ENDPATH**/ ?>